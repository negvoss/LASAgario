class Bubble {
  constructor(id,position,r,color) {
    this.id = id;
    this.position = position;
    this.r = r;
    this.color = color;
  }
  show() {
    this.displayPos = displayPos(this.position);
    noStroke();
    fill(this.color);
    ellipse(this.displayPos.x,this.displayPos.y,this.r*2);
    textAlign(CENTER);
    textSize(20);
    fill(0);
    text(this.id,this.displayPos.x,this.displayPos.y);
    textSize(14);
    text("Mass: " + round(mass(this.r)),this.displayPos.x,this.displayPos.y + 20);
  }
}
