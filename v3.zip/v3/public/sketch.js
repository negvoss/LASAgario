const socket = io.connect("http://localhost:8000/");
// const socket = io.connect("https://lasa-io.herokuapp.com/");

let bounds;
let food;
const bubbles = [];
let avgPos;

socket.on("bounds",function(data) {
  bounds = data;
});
socket.on("initFood",function(data) {
  food = data;
  for (piece of food) {
    piece.position = new Vector(piece.position.x,piece.position.y);
  }
});
socket.on("newFood",function(data) {
  data.position = new Vector(data.position.x,data.position.y);
  food.push(data);
});
socket.on("delFood",function(data) {
  food.splice(data.index,1);
});
socket.on("newBubble",function(data) {
  bubbles.push(new Bubble(data.id,new Vector(data.position.x,data.position.y),data.r,color(data.color)));
});
socket.on("updateBubble",function(data) {
  for (bubble of bubbles) {
    if (bubble.id == data.id) {
      if (data.property == "position") {
        bubble.position = new Vector(data.value.x,data.value.y);
      } else {
        bubble[data.property] = data.value;
      }
      break;
    }
  }
});

function setup() {
  createCanvas(windowWidth,windowHeight);
}

function draw() {
  background(200);
  avgPos = new Vector(0,0);
  for (bubble of bubbles) {
    avgPos = avgPos.add(bubble.position.div(bubbles.length));
  }
  if (bubbles) {
    if (food) {
      for (piece of food) {
        noStroke();
        fill(piece.color);
        const foodPos = displayPos(piece.position);
        ellipse(foodPos.x,foodPos.y,piece.r*2);
      }
    }
    if (bounds) {
      stroke(255,0,0);
      strokeWeight(3);
      noFill();
      const borderCorner = displayPos(new Vector(bounds[0],bounds[1]));
      rect(borderCorner.x,borderCorner.y,bounds[2] - bounds[0],bounds[3] - bounds[1]);
    }
    for (bubble of bubbles) {
      if (bubble) {
        bubble.show();
      }
    }
    socket.emit("mousePosition",serverPos(new Vector(mouseX,mouseY)));
  }
}

function keyPressed() {
  if (key == " ") {
    socket.emit("split");
  }
}

function windowResized() {
  resizeCanvas(windowWidth,windowHeight);
}

const displayPos = function(pos) {
  return pos.sub(avgPos).add(new Vector(width*0.5,height*0.5));
}
const serverPos = function(pos) {
  return pos.add(avgPos).sub(new Vector(width*0.5,height*0.5));
}
const pi = 3.14159;
const mass = function(r) {
  return pi*Math.pow(r,2);
}
const radius = function(m) {
  return Math.sqrt(m/pi);
}
