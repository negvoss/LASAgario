const express = require('express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io').listen(server);
const port = 8000;
server.listen(process.env.PORT || port);
app.use(express.static("public"));

class Vector {
  constructor(x,y) {
    this.x = x;
    this.y = y;
  }
  add(other) {
    return new Vector(this.x + other.x,this.y + other.y);
  }
  sub(other) {
    return new Vector(this.x - other.x,this.y - other.y);
  }
  mult(factor) {
    return new Vector(this.x*factor,this.y*factor);
  }
  div(divisor) {
    return new Vector(this.x/divisor,this.y/divisor);
  }
  dist(other) {
    return Math.sqrt(Math.pow(other.x - this.x,2) + Math.pow(other.y - this.y,2));
  }
  get mag() {
    return Math.sqrt(Math.pow(this.x,2) + Math.pow(this.y,2));
  }
}

const random = function(min,max) {
  return Math.random()*(max - min) + min;
}

const bubbleR = 40;
const foodR = 4;
const bounds = [0,0,1000,1000];
const clients = [];
const bubbles = {};
const food = [];
for (let i = 0; i < 200; i++) {
  food.push({
    position:new Vector(random(bounds[0],bounds[2]),random(bounds[1],bounds[3])),
    r:foodR,
    color:[random(50,200),random(50,200),random(50,200)]
  });
}
let nextId = 0;
io.sockets.on("connection",function(socket) {
  // console.log(socket.id + " connected");
  clients.push(socket);
  socket.emit("bounds",bounds);
  socket.emit("initFood",food);
  const bubble = {
    id:nextId,
    position:new Vector(random(bounds[0],bounds[2]),random(bounds[1],bounds[3])),
    velocity:new Vector(0,0),
    pull:new Vector(0,0),
    drag:new Vector(0,0),
    r:bubbleR,
    color:[random(50,200),random(50,200),random(50,200)]
  };
  nextId++;
  socket.emit("newBubble",bubble);
  bubbles[socket.id] = [bubble];
  socket.on("mousePosition",function(data) {
    data = new Vector(data.x,data.y);
    for (currentBubble of bubbles[socket.id]) {
      const pull = data.sub(currentBubble.position);
      if (pull.div(pull.mag).mag > 0.5) {
        currentBubble.pull = pull.div(pull.mag).mult(0.5);
      } else {
        currentBubble.pull = pull;
      }
    }
  });
  socket.on("split",function() {
    bubbles[socket.id].forEach(function(bubble) {
      if (mass(bubble.r)*0.5 >= mass(bubbleR)) {
        const newBubble = {
          id:nextId,
          position:bubble.position,
          velocity:bubble.velocity.mult(0.5*mass(bubble.r/bubbleR)),
          pull:new Vector(0,0),
          drag:new Vector(0,0),
          r:radius(mass(bubble.r)*0.5),
          color:bubble.color
        };
        bubbles[socket.id].push(newBubble);
        socket.emit("newBubble",newBubble);
        nextId++;
        bubble.r = radius(mass(bubble.r)*0.5);
        socket.emit("updateBubble",{
          id:bubble.id,
          property:"r",
          value:bubble.r
        });
        bubble.velocity = new Vector(0,0);
      }
    });
  });
  socket.on("disconnect",function() {
    // console.log(socket.id + " disconnected");
    clients.splice(socket,1);
    delete bubbles[socket.id];
  });
});

const pi = 3.14159;
const mass = function(r) {
  return pi*Math.pow(r,2);
}
const radius = function(m) {
  return Math.sqrt(m/pi);
}

const tick = function() {
  let totalMass = 0;
  for (socketId of Object.keys(bubbles)) {
    const socket = io.sockets.connected[socketId];
    for (bubble of bubbles[socketId]) {
      const velMag = bubble.velocity.mag;
      if (velMag != 0) {
        bubble.drag = bubble.velocity.mult(-1).div(velMag).mult(0.008*velMag).mult(1.6*mass(bubble.r/bubbleR));
      }
      bubble.velocity = bubble.velocity.add(bubble.pull.add(bubble.drag));
      bubble.position = bubble.position.add(bubble.velocity);
      if (bubble.position.x < bounds[0]) {
        bubble.position.x = bounds[0];
        bubble.velocity.x = 0;
      }
      if (bubble.position.y < bounds[1]) {
        bubble.position.y = bounds[1];
        bubble.velocity.y = 0;
      }
      if (bubble.position.x > bounds[2]) {
        bubble.position.x = bounds[2];
        bubble.velocity.x = 0;
      }
      if (bubble.position.y > bounds[3]) {
        bubble.position.y = bounds[3];
        bubble.velocity.y = 0;
      }
      for (let i = food.length - 1; i >= 0; i--) {
        if (bubble.position.dist(food[i].position) <= bubble.r) {
          bubble.r = radius(mass(bubble.r) + mass(food[i].r));
          food.splice(i,1);
          io.emit("delFood",{
            index:i
          });
          const newFood = {
            position:new Vector(random(bounds[0],bounds[2]),random(bounds[1],bounds[3])),
            r:foodR,
            color:[random(50,200),random(50,200),random(50,200)]
          };
          food.push(newFood);
          io.emit("newFood",newFood);
        }
      }
      socket.emit("updateBubble",{
        id:bubble.id,
        property:"position",
        value:bubble.position
      });
      bubble.r = radius(mass(bubble.r) - 1);
      if (bubble.r < bubbleR) {
        bubble.r = bubbleR
      }
      socket.emit("updateBubble",{
        id:bubble.id,
        property:"r",
        value:bubble.r
      });
    }
  }
  setTimeout(tick,16.666);
}
tick();
