const express = require('express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io').listen(server);
const port = 8000;
server.listen(process.env.PORT || port);
app.use(express.static("public"));

const random = function(min,max) {
  return Math.random()*(max - min) + min;
}

const bubbleR = 40;
const foodR = 4;
const bounds = [0,0,1000,1000];
const clients = [];
const bubbles = {};
const food = [];
for (let i = 0; i < 200; i++) {
  food.push({
    x:random(bounds[0],bounds[2]),
    y:random(bounds[1],bounds[3]),
    r:foodR,
    color:[random(50,200),random(50,200),random(50,200)]
  });
}
let nextId = 0;
io.sockets.on("connection",function(socket) {
  // console.log(socket.id + " connected");
  clients.push(socket);
  socket.emit("bounds",bounds);
  socket.emit("initFood",food);
  const bubble = {
    id:nextId,
    position: {
      x:random(bounds[0],bounds[2]),
      y:random(bounds[1],bounds[3]),
    },
    direction: {
      x:0,
      y:0
    },
    boost: {
      x:0,
      y:0
    },
    boostTimer:null,
    r:2*bubbleR,
    color:[random(50,200),random(50,200),random(50,200)]
  };
  nextId++;
  socket.emit("newBubble",bubble);
  bubbles[socket.id] = [bubble];
  socket.on("mousePosition",function(data) {
    for (currentBubble of bubbles[socket.id]) {
      currentBubble.direction = {
        x:0.05*(data.x - currentBubble.position.x),
        y:0.05*(data.y - currentBubble.position.y)
      };
    }
  });
  socket.on("split",function() {
    bubbles[socket.id].forEach(function(bubble) {
      if (mass(bubble.r)*0.5 >= mass(bubbleR)) {
        bubble.r = radius(mass(bubble.r)*0.5);
        socket.emit("updateBubble",{
          id:bubble.id,
          property:"r",
          value:bubble.r
        });
        const newBubble = {
          id:nextId,
          position: {
            x:bubble.position.x,
            y:bubble.position.y
          },
          direction:bubble.direction,
          boost: {
            x:bubble.direction.x*200,
            y:bubble.direction.y*200
          },
          boostTimer:0,
          r:bubble.r,
          color:bubble.color
        };
        bubbles[socket.id].push(newBubble);
        socket.emit("newBubble",newBubble);
        nextId++;
      }
    });
  });
  socket.on("disconnect",function() {
    // console.log(socket.id + " disconnected");
    clients.splice(socket,1);
    delete bubbles[socket.id];
  });
});

const pi = 3.14159;
const mass = function(r) {
  return pi*Math.pow(r,2);
}
const radius = function(m) {
  return Math.sqrt(m/pi);
}

const tick = function() {
  let totalMass = 0;
  for (socketId of Object.keys(bubbles)) {
    const socket = io.sockets.connected[socketId];
    for (bubble of bubbles[socketId]) {
      const magLimit = 6*Math.pow(2,-0.00005*(mass(bubble.r) - mass(bubbleR)));
      const mag = dist(0,0,bubble.direction.x,bubble.direction.y);
      if (mag > magLimit) {
        bubble.direction = {
          x:magLimit*(bubble.direction.x/mag),
          y:magLimit*(bubble.direction.y/mag)
        };
      }
      if (bubble.boostTimer != null) {
        if (bubble.boostTimer <= 60) {
          const boostMag = dist(0,0,bubble.boost.x,bubble.boost.y);
          bubble.boost = {
            x:0.005*Math.pow(bubble.boostTimer - 60,2)*(bubble.boost.x/boostMag),
            y:0.005*Math.pow(bubble.boostTimer - 60,2)*(bubble.boost.y/boostMag),
          };
          bubble.boostTimer++;
        } else {
          bubble.boostTimer = null;
        }
      }
      bubble.position.x += bubble.direction.x + bubble.boost.x;
      bubble.position.y += bubble.direction.y + bubble.boost.y;
      if (bubble.position.x < bounds[0]) bubble.position.x = bounds[0];
      if (bubble.position.y < bounds[1]) bubble.position.y = bounds[1];
      if (bubble.position.x > bounds[2]) bubble.position.x = bounds[2];
      if (bubble.position.y > bounds[3]) bubble.position.y = bounds[3];
      for (let i = food.length - 1; i >= 0; i--) {
        if (dist(bubble.position.x,bubble.position.y,food[i].x,food[i].y) <= bubble.r) {
          bubble.r = radius(mass(bubble.r) + mass(food[i].r));
          food.splice(i,1);
          io.emit("delFood",{
            index:i
          });
          const newFood = {
            x:random(bounds[0],bounds[2]),
            y:random(bounds[1],bounds[3]),
            r:foodR,
            color:[random(50,200),random(50,200),random(50,200)]
          };
          food.push(newFood);
          io.emit("newFood",newFood);
        }
      }
      socket.emit("updateBubble",{
        id:bubble.id,
        property:"position",
        value:bubble.position
      });
      bubble.r = radius(mass(bubble.r) - 1);
      if (bubble.r < bubbleR) {
        bubble.r = bubbleR
      }
      socket.emit("updateBubble",{
        id:bubble.id,
        property:"r",
        value:bubble.r
      });
    }
  }
  setTimeout(tick,16.66);
}
tick();

const dist = function(x1,y1,x2,y2) {
  return Math.sqrt(Math.pow(x2 - x1,2) + Math.pow(y2 - y1,2));
}
