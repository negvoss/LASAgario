const socket = io.connect("http://localhost:8000/");
// const socket = io.connect("https://lasa-io.herokuapp.com/");

let bounds;
let food;
const bubbles = [];
let averageX;
let averageY;

socket.on("bounds",function(data) {
  bounds = data;
});
socket.on("initFood",function(data) {
  food = data;
});
socket.on("newFood",function(data) {
  food.push(data);
});
socket.on("delFood",function(data) {
  food.splice(data.index,1);
});
socket.on("newBubble",function(data) {
  bubbles.push(new Bubble(data.id,data.position,data.r,color(data.color)));
});
socket.on("updateBubble",function(data) {
  for (bubble of bubbles) {
    if (bubble.id == data.id) {
      bubble[data.property] = data.value;
      break;
    }
  }
});

function setup() {
  createCanvas(windowWidth,windowHeight);
}

function draw() {
  background(200);
  let totalX = 0;
  let totalY = 0;
  for (bubble of bubbles) {
    totalX += bubble.position.x;
    totalY += bubble.position.y;
  }
  averageX = totalX/bubbles.length;
  averageY = totalY/bubbles.length;
  if (bubbles) {
    if (food) {
      for (piece of food) {
        noStroke();
        fill(piece.color);
        ellipse(displayX(piece.x),displayY(piece.y),piece.r*2);
      }
    }
    if (bounds) {
      stroke(255,0,0);
      strokeWeight(3);
      noFill();
      rect(displayX(bounds[0]),displayY(bounds[1]),bounds[2] - bounds[0],bounds[3] - bounds[1]);
    }
    for (bubble of bubbles) {
      if (bubble) {
        bubble.show();
      }
    }
  }
  socket.emit("mousePosition",{
    x:serverX(mouseX),
    y:serverY(mouseY)
  });
}

function keyPressed() {
  if (key == " ") {
    socket.emit("split");
  }
}

function windowResized() {
  resizeCanvas(windowWidth,windowHeight);
}

const displayX = function(x) {
  return x - averageX + width*0.5;
}
const displayY = function(y) {
  return y - averageY + height*0.5;
}
const serverX = function(x) {
  return x + averageX - width*0.5;
}
const serverY = function(y) {
  return y + averageY - height*0.5;
}
const pi = 3.14159;
const mass = function(r) {
  return pi*Math.pow(r,2);
}
const radius = function(m) {
  return Math.sqrt(m/pi);
}
