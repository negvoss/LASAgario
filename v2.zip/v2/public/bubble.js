class Bubble {
  constructor(id,position,r,color) {
    this.id = id;
    this.position = position;
    this.r = r;
    this.color = color;
  }
  show() {
    noStroke();
    fill(this.color);
    ellipse(displayX(this.position.x),displayY(this.position.y),this.r*2);
    textAlign(CENTER);
    textSize(20);
    fill(0);
    text(this.id,displayX(this.position.x),displayY(this.position.y));
    textSize(14);
    text("Mass: " + round(mass(this.r)),displayX(this.position.x),displayY(this.position.y) + 20);
  }
}
